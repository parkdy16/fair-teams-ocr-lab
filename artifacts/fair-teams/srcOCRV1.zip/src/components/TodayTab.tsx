import React, { useState } from "react";
import type { RoomPlayer } from "@/lib/localRoster";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Camera, Mic, Search, Upload, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";


function displayName(player: Pick<RoomPlayer, "name" | "aka">) {
  const aka = player.aka?.trim();
  return aka ? `${player.name} (${aka})` : player.name;
}

function NewBadge() {
  return <span className="inline-flex items-center rounded-full bg-sky-100 px-1.5 py-0.5 text-[9px] font-black text-sky-800 border border-sky-200">NEW</span>;
}
function GKBadge() {
  return <span className="inline-flex items-center rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9px] font-black text-emerald-800 border border-emerald-200">GK</span>;
}

function ORGBadge() {
  return <span className="inline-flex items-center rounded-full bg-orange-100 px-1.5 py-0.5 text-[9px] font-black text-orange-800 border border-orange-200">ORG</span>;
}

export function TodayTab({ players, setPlayers }: { players: RoomPlayer[]; setPlayers: (players: RoomPlayer[]) => void }) {
  const [search, setSearch] = useState("");
  const [ocrOpen, setOcrOpen] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [selectedScreenshotNames, setSelectedScreenshotNames] = useState<string[]>([]);

  const sorted = [...players].sort((a, b) => a.name.localeCompare(b.name));
  const filtered = search.trim()
    ? sorted.filter(p => displayName(p).toLowerCase().includes(search.toLowerCase()))
    : sorted;

  const selectedCount = players.filter(p => p.attending).length;

  const togglePlayer = (player: RoomPlayer) => {
    setPlayers(players.map(p => p.id === player.id ? { ...p, attending: !p.attending } : p));
  };

  if (players.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground font-medium">Add players in the Roster tab first.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between bg-primary text-primary-foreground p-3 rounded-xl shadow-sm">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">Attending Today</span>
          <span className="text-xl font-black leading-tight">{selectedCount} <span className="text-xs font-medium opacity-80">/ {players.length}</span></span>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => setPlayers(players.map(p => ({ ...p, attending: true })))} className="h-7 text-[10px] font-bold uppercase px-2" >
            All
          </Button>
          <Button variant="secondary" size="sm" onClick={() => setPlayers(players.map(p => ({ ...p, attending: false })))} className="h-7 text-[10px] font-bold uppercase px-2 opacity-80 hover:opacity-100 bg-slate-900/10 hover:bg-slate-900/20 text-white border-transparent" >
            Clear
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setOcrOpen(true)}
          className="h-9 rounded-xl text-xs font-black"
          data-testid="ocr-import-button"
        >
          <Camera className="mr-1.5 h-3.5 w-3.5" />
          OCR Import
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setVoiceOpen(true)}
          className="h-9 rounded-xl text-xs font-black"
          data-testid="voice-import-button"
        >
          <Mic className="mr-1.5 h-3.5 w-3.5" />
          Voice Import
        </Button>
      </div>

      <Dialog open={ocrOpen} onOpenChange={setOcrOpen}>
        <DialogContent className="w-[92vw] max-w-md rounded-2xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base font-black">OCR Import</DialogTitle>
            <DialogDescription className="text-xs">
              Import today's attendees from a Meetup, WhatsApp, Telegram, or list screenshot.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <label className="flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-muted/40 p-4 text-center transition-colors hover:bg-muted/70">
              <Upload className="h-6 w-6 text-muted-foreground" />
              <div className="text-xs font-black text-foreground">
                {selectedScreenshotNames.length > 0 ? `${selectedScreenshotNames.length} screenshot${selectedScreenshotNames.length === 1 ? "" : "s"} selected` : "Choose Screenshot(s)"}
              </div>
              <div className="text-[10px] font-medium text-muted-foreground">
                Select all screenshots for one attendee list. OCR engine will be connected in the next step.
              </div>
              <input
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(event) => setSelectedScreenshotNames(Array.from(event.target.files ?? []).map(file => file.name))}
                data-testid="ocr-file-input"
              />
            </label>

            {selectedScreenshotNames.length > 0 && (
              <div className="rounded-xl border bg-card p-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">Selected Screenshots</div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedScreenshotNames([])}
                    className="h-7 px-2 text-[10px] font-black"
                  >
                    Clear
                  </Button>
                </div>
                <div className="max-h-28 space-y-1 overflow-y-auto pr-1">
                  {selectedScreenshotNames.map((name, index) => (
                    <div key={`${name}-${index}`} className="truncate rounded-lg bg-muted/50 px-2.5 py-1.5 text-[11px] font-medium text-foreground">
                      {index + 1}. {name}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="rounded-xl border bg-card p-3">
              <div className="mb-2 text-[10px] font-black uppercase tracking-wider text-muted-foreground">Detected Names</div>
              <div className="rounded-lg bg-muted/50 p-3 text-center text-xs font-medium text-muted-foreground">
                Names from the screenshot will appear here before anything is added.
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button type="button" variant="outline" onClick={() => setOcrOpen(false)} className="h-9 text-xs font-bold">
              Cancel
            </Button>
            <Button type="button" disabled className="h-9 text-xs font-black">
              Add All
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={voiceOpen} onOpenChange={setVoiceOpen}>
        <DialogContent className="w-[92vw] max-w-md rounded-2xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base font-black">Voice Import</DialogTitle>
            <DialogDescription className="text-xs">
              Voice roll call will come later. OCR screenshot import comes first.
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-xl border bg-muted/50 p-4 text-center text-xs font-medium text-muted-foreground">
            Coming soon.
          </div>
          <DialogFooter>
            <Button type="button" onClick={() => setVoiceOpen(false)} className="h-9 text-xs font-black">
              OK
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
        <Input
          placeholder="Search players…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="h-9 pl-8 pr-8 text-xs"
          data-testid="today-search"
        />
        {search && (
          <button
            onClick={() => setSearch("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-8 bg-muted/50 rounded-xl border border-dashed border-border">
          <p className="text-muted-foreground font-medium text-xs">No players match "{search}"</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-1.5">
          {filtered.map(player => (
            <label
              key={player.id}
              className={`flex items-center gap-2 px-2.5 py-2 border rounded-lg cursor-pointer transition-colors ${player.attending ? "border-primary bg-primary/5" : "border-border bg-card"}`}
              data-testid={`attendance-row-${player.id}`}
            >
              <Checkbox
                checked={!!player.attending}
                onCheckedChange={() => togglePlayer(player)}
                className="w-4 h-4 rounded-full border-2 shrink-0 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                data-testid={`attendance-check-${player.id}`}
              />
              <div className="flex flex-col min-w-0 flex-1">
                <div className={`font-bold text-xs truncate leading-tight ${player.attending ? "text-primary" : "text-foreground"}`}>{displayName(player)}</div>
                <div className="mt-0.5 flex items-center gap-1 min-w-0">
                  <span className="text-[10px] text-muted-foreground font-medium shrink-0">OVR {player.skill} · TP {player.teamPlay ?? 2}</span>
                  {(player.isNew || player.isGoalkeeper || player.isOrganizer) && (
                    <div className="flex flex-wrap gap-1 min-w-0">
                      {player.isNew && <NewBadge />}{player.isGoalkeeper && <GKBadge />}
                      {player.isOrganizer && <ORGBadge />}
                    </div>
                  )}
                </div>
              </div>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}
