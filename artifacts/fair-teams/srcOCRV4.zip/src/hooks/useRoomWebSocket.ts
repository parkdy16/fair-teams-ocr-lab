export function useRoomWebSocket() {
  return;
}
